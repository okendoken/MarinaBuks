INSERT INTO questions ('id', 'questionText', 'created_at', 'updated_at') VALUES
(1, 'What are your talents?', '2012-01-12 21:14:50', '2012-01-12 21:15:31'),
(2, 'What excites you?', '2012-01-12 21:15:56', '2012-01-12 21:15:56'),
(3, 'What do you read about?', '2012-01-12 21:16:38', '2012-01-12 21:16:38');