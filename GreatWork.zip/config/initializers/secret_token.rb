# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
GreatWork::Application.config.secret_token = '6d3f6361bf1323e316a1be3ce060e2c11f5d3d97c8bb0a2c02dbe7211542e4f7a80c120e1147783664409b6fd3ebbf39b22eb86aa00a6390e8f58938e1197a55'
