class AnswersController < ApplicationController
end