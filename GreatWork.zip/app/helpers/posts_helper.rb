module PostsHelper
end
